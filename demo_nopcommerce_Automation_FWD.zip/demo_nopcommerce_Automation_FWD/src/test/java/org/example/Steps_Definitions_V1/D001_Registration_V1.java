package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P001_Registration_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;

import java.util.Random;

public class D001_Registration_V1 {
    P001_Registration_V1 RegObj=new P001_Registration_V1();
    @Given("Guest User navigate to the register page")
            public void navigateRegisterPage()
    {
      RegObj.clickRegister().click();
    }

    @When("Guest user select gender type")
    public void selectGender() {
        RegObj.selectGender().click();
    }

    @And("Guest user enter firstname {string} and lastname {string}")
    public void enterFirstAndLastName(String Name1, String Name2) {
        RegObj.enterFirstName().sendKeys(Name1);
        RegObj.enterSecName().sendKeys(Name2);
    }


    @And("Guest user enter date of birth")
    public void enterBirthDate() {
        Select selectDay=new Select(RegObj.enterDatDay());
        selectDay.selectByIndex(10);
        Select selectMonth=new Select(RegObj.enterDateMonth());
        selectMonth.selectByValue("6");
        Select selectYear=new Select(RegObj.enterDateYear());
        selectYear.selectByValue("1991");


    }
    @And("Guest user enter email address {string}")
    public void enterEmail(String mail) {
        RegObj.enterMail().sendKeys(mail);

    }
    @And("Guest user fills Password field {string} and confirmation Password field {string}")
    public void guestUserFillsPasswordFieldAndConfirmationPasswordField(String pass, String confPass) {
        RegObj.enterPassword1().sendKeys(pass);
        RegObj.enterPassword2().sendKeys(confPass);
    }

    @And("Guest user clicks on register button")
    public void clicksRegisterBut() throws InterruptedException {
        RegObj.registerButEle().click();
        Thread.sleep(500);
    }

    @Then("success message is displayed")
    public void successMessageIsDisplayed() {
        SoftAssert soft =new SoftAssert();
        String ExpectedResult="Your registration completed";
        String ActualResult=Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"result\"]")).getText();
        System.out.println(ActualResult);
                soft.assertEquals(ActualResult.contains(ExpectedResult),true);
               String ExpectedColor="rgba(76, 177, 124, 1)";
               String ActualColor=Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"result\"]")).getCssValue("color");
        soft.assertTrue(ActualColor.equals(ExpectedColor),"sec Assertion_Wrong color message");
        System.out.println(ActualColor);
        soft.assertAll();
    }



}
