package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import java.time.Duration;

public class D008__Wishlist_V1 {
    P003_HomePage_V1 wishlist=new P003_HomePage_V1();
    @When("user click on wishlist Icon")
    public void clickWishlistIcon() throws InterruptedException {
//        for (int i=0;i<wishlist.clickWishListBut().size();i++){
//        wishlist.clickWishListBut().get(i).click();}
        wishlist.clickWishListIcon().get(2).click();
        Thread.sleep(2000);


    }

    @Then("item is added successfully to  wishlist")
    public void itemIsAddedSuccessfullyToWishlist() {
 String ActualMessage=wishlist.successMessage().getText();
        SoftAssert soft=new SoftAssert();
        String ExpectedMessage="The product has been added to your wishlist";

        soft.assertEquals(ActualMessage.contains(ExpectedMessage),true,"1st Assertion_wrong message");

        String ExpectedBackgroundColor="#4bb07a";
        String ActualBackgroundColor=wishlist.BackGroundColor().getCssValue("background-color");
        String ActualBackgroundColorHex= Color.fromString(ActualBackgroundColor).asHex();

 soft.assertEquals(ActualBackgroundColorHex.equals(ExpectedBackgroundColor),true,"sec_Assertion Wrong Back_ground color");
        soft.assertAll();
    }

    @When("user click on wishlist button")
    public void userClickOnWishlistButton() throws InterruptedException {
        WebDriverWait wait=new WebDriverWait(Hooks_V1.chromeDriver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.invisibilityOf(wishlist.BackGroundColor()));
        wishlist.clickWishListBut().click();
        Thread.sleep(1000);
    }



    @Then("user is directed to {string} wishlist page")
    public void userIsDirectedToWishlistPage(String wishlistURL) {
        SoftAssert soft=new SoftAssert();
        String ActualURL=Hooks_V1.chromeDriver.getCurrentUrl();
        System.out.println(ActualURL);
        soft.assertEquals(ActualURL.equals(wishlistURL),true,"1st Assertion_wrong wishlist URL");
        String QTY=wishlist.wishlistValue().getAttribute("value");
        int qtyValue= Integer.valueOf(QTY);
        System.out.println(qtyValue);
soft.assertTrue(qtyValue>0,"Sec Assertion_number is <= 0");
soft.assertAll();

    }
}
