package org.example.Steps_Definitions_V1;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.example.Pages_SRC_V1.P001_Registration_V1;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks_V1 {
   public static WebDriver chromeDriver;
static P001_Registration_V1 Register;

    @Before
    public static void openChromeBrowser()  {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Ahmed Saad\\IdeaProjects\\demo_nopcommerce_Automation_FWD\\src\\main\\resources\\chromedriver.exe");
    chromeDriver=new ChromeDriver();
    chromeDriver.manage().window().maximize();
chromeDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    chromeDriver.navigate().to("https://demo.nopcommerce.com/");

    }
    @After
    public static void quitChromeBrowser()throws InterruptedException{
        Thread.sleep(3000);
        chromeDriver.quit();
    }
}
