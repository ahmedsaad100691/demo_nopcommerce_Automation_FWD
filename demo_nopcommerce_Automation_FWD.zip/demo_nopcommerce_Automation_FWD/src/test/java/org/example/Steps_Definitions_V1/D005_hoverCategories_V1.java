package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import java.util.List;
import java.util.Random;

public class D005_hoverCategories_V1 {
    int CategoryNu=new Random().nextInt(3);
    int SubCategoryNu=new Random().nextInt(3);


    P003_HomePage_V1 hooverObj=new P003_HomePage_V1();
    @When("user hover over category menu and select item from subcategory list")
    public void hooverCategoryPage() throws InterruptedException {
        //Random way
        //        Random randomCategoryNu=new Random();
        //        randomCategoryNu.nextInt(3);
        Actions hooverAction=new Actions(Hooks_V1.chromeDriver);
        hooverAction.moveToElement(hooverObj.categoryEle().get(CategoryNu)).perform();
      String categoryName  =hooverObj.categoryEle().get(CategoryNu).getText();
        System.out.println(categoryName);
        hooverObj.subCategoryEle(CategoryNu).get(SubCategoryNu).click();
        Thread.sleep(3000);
    }


    @Then("user is able to see the subcategory page")
    public void displaySubcategoryPage() {
        SoftAssert categoryAssertion=new SoftAssert();

        String subCategoryName=hooverObj.subCategoryEle(CategoryNu).get(SubCategoryNu).getText().toLowerCase();
        String itemText=hooverObj.subCategoryTextPDP().getText().toLowerCase();
        categoryAssertion.assertEquals(itemText.contains(subCategoryName),true,"first Assertion_different item");

        String actualURL=Hooks_V1.chromeDriver.getCurrentUrl();
      String expectedURL="https://demo.nopcommerce.com/"+itemText;
       categoryAssertion.assertEquals(actualURL.contains(expectedURL),true,"sec assertion_URL is different");
   categoryAssertion.assertAll();
    }
}
