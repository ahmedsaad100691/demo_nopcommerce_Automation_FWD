package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.*;


public class D006_HomeSliders_V1 {
    P003_HomePage_V1 sliderObj=new P003_HomePage_V1();
    @When("user click on the first slider")
    public void clickFirstSlider() throws InterruptedException {

            sliderObj.SliderEle().get(0).click();
            Thread.sleep(3000);

    }
    @Then("user is directed to {string} item page")
    public void userIsDirectedToItemPage(String URL) {
        String actualURL=Hooks_V1.chromeDriver.getCurrentUrl();
        Assert.assertEquals(actualURL.contains(URL),true,"Wrong URL");
    }
    @When("user click on the second slider")
    public void clickSecondSlider()  {
        sliderObj.SliderEle().get(1).click();

    }



}
