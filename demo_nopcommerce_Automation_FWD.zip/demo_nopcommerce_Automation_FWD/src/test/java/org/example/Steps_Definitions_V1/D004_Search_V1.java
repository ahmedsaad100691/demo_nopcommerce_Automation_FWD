package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D004_Search_V1 {
    P003_HomePage_V1 search=new P003_HomePage_V1();

    @When("user enter {string} into search field")
    public void userEnter(String input) {
        search.searchItem().sendKeys(input);
    }
    @And("user click on search button")
    public void clickSearchButt() {
        search.clickSearchButton().click();
    }

    @Then("Relative results of {string} are displayed in PLP")
    public void displayedResult(String results) {
        SoftAssert products=new SoftAssert();
        String expectedResult=results;
        for (int i = 0; i < search.findProductList().size(); i++)
        {
            String ActualResult = search.findProductList().get(i).getText().toLowerCase();
            products.assertEquals(ActualResult.contains(expectedResult),true,"1st assertion_Product is not found");
        }
        String expectedURL="https://demo.nopcommerce.com/search?q=";
        String actualURL=Hooks_V1.chromeDriver.getCurrentUrl();
        products.assertTrue(actualURL.contains(expectedURL),"Second Assertion_URL");

        products.assertAll();

    }

    @Then("Relative results of {string} are displayed in PDP")
  public void itemsDisplayedInPLP(String items) {
        String expectedSKU=items;
            search.openPDP().click();
           String actualSKU=  search.verifySKU().getText();
            Assert.assertEquals(actualSKU.contains(expectedSKU),true,"1st Assertion_wrong sku");
   }
    }

