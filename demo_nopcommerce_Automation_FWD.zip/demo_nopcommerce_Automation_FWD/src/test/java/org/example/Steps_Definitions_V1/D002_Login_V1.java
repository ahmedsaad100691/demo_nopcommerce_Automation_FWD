package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P002_Login_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D002_Login_V1 {
    P002_Login_V1 login=new P002_Login_V1();
    @Given("user navigate to login page")
    public void navigateLoginPage(){
        login.navigateLoginButEle().click();
    }

    @When("user enter email {string} and password {string}")
    public void userEnterEmailAndPassword(String email, String pass) {
        login.enterLoginUser().clear();
        login.enterLoginUser().sendKeys(email);
        login.enterLoginPass().sendKeys(pass);
    }

    @And("user press on login button")
    public void userPressOnLoginButton() {
       login.clickLoginBut().click();

    }

    @Then("user Could login to the system successfully")
    public void userCouldLoginToTheSystemSuccessfully() {
       login.myAccountFeature().isDisplayed();
       login.LogoutFeature().isDisplayed();
       String ActualResult=Hooks_V1.chromeDriver.getCurrentUrl();
       String ExpectedResult="https://demo.nopcommerce.com/";
        Assert.assertEquals(ActualResult.contains(ExpectedResult),true);
    }


    @Then("user is not allowed to login to the system")
    public void userIsNotAllowedToLoginToTheSystem() {
       SoftAssert  soft2 =new SoftAssert();
        String ActualResult=Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getText();
        String ExpectedResult="Login was unsuccessful. Please correct the errors and try again.";
        soft2.assertEquals(ActualResult.contains(ExpectedResult),true,"1st Assertion");

        String ActualTextColor=Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"message-error validation-summary-errors\"]")).getCssValue("color");
       String HexColor=Color.fromString(ActualTextColor).asHex();
        String ExpectedTextColor="#e4434b";
        System.out.println(HexColor);
        soft2.assertEquals(HexColor.equals(ExpectedTextColor),true,"sec Assertion");
        soft2.assertAll();
    }


}
