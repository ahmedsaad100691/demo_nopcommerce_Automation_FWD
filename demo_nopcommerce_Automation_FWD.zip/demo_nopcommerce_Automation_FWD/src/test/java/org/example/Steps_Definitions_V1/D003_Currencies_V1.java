package org.example.Steps_Definitions_V1;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D003_Currencies_V1 {
    P003_HomePage_V1 Currency= new P003_HomePage_V1();
    @When("user select Euro currency from dropdown_list")
    public void selectEuro() {
        Select selectCurrency = new Select(Currency.EuroEle());
        selectCurrency.selectByVisibleText("Euro");


    }


    @Then("All products are displayed with Euro currency")
    public void allProductsAreDisplayedWithEuroCurrency() {
        String expectedResult="€";
        for(int i=0;i < Currency.findProductsPrice().size();i++)
        {
            String ActualResult= Currency.findProductsPrice().get(i).getText();
            Assert.assertEquals(ActualResult.contains(expectedResult),true,"currency  is not match");
        }

    }
}
