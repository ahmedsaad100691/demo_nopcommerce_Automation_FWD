package org.example.Steps_Definitions_V1;

import io.cucumber.java.AfterStep;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages_SRC_V1.P003_HomePage_V1;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class D007__followUs_V1 {
    P003_HomePage_V1 links=new P003_HomePage_V1();
    WebDriverWait wait=new WebDriverWait(Hooks_V1.chromeDriver, Duration.ofSeconds(5));


    @When("user click on facebook icon")
    public void clickFacebook() throws InterruptedException {
        links.facebook().click();


    }
    @Then("user is directed to {string}")
    public void userIsDirectedTo(String URL) {
        ArrayList<String> tabs=  new ArrayList<>(Hooks_V1.chromeDriver.getWindowHandles());
        Hooks_V1.chromeDriver.switchTo().window(tabs.get(1));
        wait.until(ExpectedConditions.urlToBe(URL));
        String actualURL=Hooks_V1.chromeDriver.getCurrentUrl();
        System.out.println("Saad"+actualURL);
        Assert.assertEquals(actualURL,URL,"The URL is Wrong");
    }

    @When("user click on twitter icon")
    public void clickTwitterIcon() {
        links.twitter().click();
    }


    @When("user click on rss icon")
    public void clickRssIcon() {
        links.rss().click();
    }



    @When("user click on youtube icon")
    public void clickYoutubeIcon() {
        links.youtube().click();
    }


}
