package org.example.Pages_SRC_V1;

import org.example.Steps_Definitions_V1.Hooks_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class P002_Login_V1 {
    public WebElement navigateLoginButEle(){
        WebElement LoginButEle= Hooks_V1.chromeDriver.findElement(By.cssSelector("a[class=\"ico-login\"]"));
        return LoginButEle;
    }
    public WebElement enterLoginUser(){
        WebElement LoginUserEle =Hooks_V1.chromeDriver.findElement(By.id("Email"));
        return LoginUserEle;
    }
    public WebElement enterLoginPass(){
        WebElement LoginPassEle =Hooks_V1.chromeDriver.findElement(By.id("Password"));
        return LoginPassEle;
    }
    public WebElement clickLoginBut(){
        WebElement LoginButEle2 = Hooks_V1.chromeDriver.findElement(By.cssSelector("button[class=\"button-1 login-button\"]"));
        return LoginButEle2;
    }

    public WebElement myAccountFeature(){
        WebElement myAccountButEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("a[class=\"ico-account\"]"));
   return myAccountButEle;
    }
    public WebElement LogoutFeature(){
        WebElement LogoutEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("a[class=\"ico-logout\"]"));
        return LogoutEle;
    }}
