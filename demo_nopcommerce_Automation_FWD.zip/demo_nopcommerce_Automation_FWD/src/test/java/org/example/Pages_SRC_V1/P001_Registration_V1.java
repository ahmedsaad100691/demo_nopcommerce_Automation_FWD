package org.example.Pages_SRC_V1;

import org.example.Steps_Definitions_V1.Hooks_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P001_Registration_V1 {


    public WebElement clickRegister(){
       WebElement RegisterEle = Hooks_V1.chromeDriver.findElement(By.cssSelector("a[href=\"/register?returnUrl=%2F\" ]"));
        return RegisterEle;
    }
    public WebElement selectGender(){
       WebElement genderEle=Hooks_V1.chromeDriver.findElement(By.className("male"));
        return genderEle;
    }
    public WebElement enterFirstName(){
        WebElement firstNameEle= Hooks_V1.chromeDriver.findElement(By.id("FirstName"));
        return firstNameEle;
    }
    public WebElement enterSecName(){
        WebElement secNameEle= Hooks_V1.chromeDriver.findElement(By.id("LastName"));

        return secNameEle;
    }
    public WebElement enterDatDay() {
        WebElement Day = Hooks_V1.chromeDriver.findElement(By.name("DateOfBirthDay"));

        return Day;
    }
        public WebElement enterDateMonth(){
            WebElement Month =Hooks_V1.chromeDriver.findElement(By.name("DateOfBirthMonth"));

            return Month;
    }
    public WebElement enterDateYear() {

        WebElement Year = Hooks_V1.chromeDriver.findElement(By.name("DateOfBirthYear"));

        return Year;
    }
    public WebElement enterMail(){
        WebElement mailEle= Hooks_V1.chromeDriver.findElement(By.id("Email"));
        return mailEle;
    }
    public WebElement enterPassword1(){
        WebElement PassEle= Hooks_V1.chromeDriver.findElement(By.id("Password"));
        return PassEle;
    }
    public WebElement enterPassword2(){
        WebElement ConfirmPassEle=Hooks_V1.chromeDriver.findElement(By.id("ConfirmPassword"));
        return ConfirmPassEle;
    }
    public WebElement registerButEle(){
        WebElement RegButEle=Hooks_V1.chromeDriver.findElement(By.id("register-button"));
        return RegButEle;
    }

}
