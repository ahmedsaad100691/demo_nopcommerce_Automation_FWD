package org.example.Pages_SRC_V1;
import org.example.Steps_Definitions_V1.D005_hoverCategories_V1;
import org.example.Steps_Definitions_V1.Hooks_V1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class P003_HomePage_V1 {



    public WebElement EuroEle() {

        WebElement EuroCurrEle = Hooks_V1.chromeDriver.findElement(By.id("customerCurrency"));
        return EuroCurrEle;
    }

    public List<WebElement> findProductsPrice() {

        List<WebElement> priceList = Hooks_V1.chromeDriver.findElements(By.cssSelector("span[class=\"price actual-price\"]"));
        return priceList;
    }

    public WebElement searchItem() {
        WebElement searchEle = Hooks_V1.chromeDriver.findElement(By.id("small-searchterms"));
        return searchEle;
    }

    public WebElement clickSearchButton() {
        WebElement searchButtonEle = Hooks_V1.chromeDriver.findElement(By.cssSelector("button[class=\"button-1 search-box-button\"]"));
        return searchButtonEle;
    }

    public List<WebElement> findProductList() {
        List<WebElement> productList = Hooks_V1.chromeDriver.findElements(By.cssSelector("h2[class=\"product-title\"]"));
        return productList;
    }

    public WebElement openPDP() {
        WebElement PDPEle = Hooks_V1.chromeDriver.findElement(By.cssSelector("h2[class=\"product-title\"]>a"));
        return PDPEle;
    }

    public WebElement verifySKU() {
        WebElement SKUEle = Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"sku\"]"));
        return SKUEle;
    }
    public List<WebElement> categoryEle(){
        List<WebElement> categoryEle=Hooks_V1.chromeDriver.findElements(By.cssSelector("ul[class=\"top-menu notmobile\"]>li>a[href]"));
        return categoryEle;
    }
    public List<WebElement> subCategoryEle(int random){
        List<WebElement> subcategoryEle=Hooks_V1.chromeDriver.findElements(By.xpath("//ul[@class=\"top-menu notmobile\"]/li["+(random+1)+"]/ul[@class=\"sublist first-level\"]/li/a"));
   return subcategoryEle;
    }
    public WebElement subCategoryTextPDP(){
        WebElement itemText=Hooks_V1.chromeDriver.findElement(By.cssSelector("div[class=\"page-title\"]>h1"));
    return itemText;
    }
    public List<WebElement> SliderEle(){
        List<WebElement> Slider=Hooks_V1.chromeDriver.findElements(By.cssSelector("div[id=\"nivo-slider\"]>a"));
        return Slider;
    }
public WebElement facebook(){
        WebElement facebookEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("[class=\"facebook\"]>a"));
        return facebookEle;
}
    public WebElement twitter(){
        WebElement twitterEle=Hooks_V1.chromeDriver.findElement(By.className("twitter"));
        return twitterEle;
    }
    public WebElement rss(){
        WebElement rssEle=Hooks_V1.chromeDriver.findElement(By.className("rss"));
        return rssEle;
    }
    public WebElement youtube(){
        WebElement youtubeEle=Hooks_V1.chromeDriver.findElement(By.className("youtube"));
        return youtubeEle;
    }
    public List<WebElement> clickWishListIcon(){
    List<WebElement> wishListIconEle=Hooks_V1.chromeDriver.findElements(By.cssSelector("button[title=\"Add to wishlist\"]"));
    return wishListIconEle;
    }
    public WebElement successMessage(){
        WebElement successMessageEle=Hooks_V1.chromeDriver.findElement(By.className("content"));
        return successMessageEle;
    }
    public WebElement BackGroundColor(){
        WebElement BackGroundColorEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("div [class=\"bar-notification success\"]"));
        return BackGroundColorEle;
    }
    public WebElement clickWishListBut(){
        WebElement wishListButEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("a[class=\"ico-wishlist\"]"));
        return wishListButEle;
    }
    public WebElement wishlistValue(){
        WebElement wishlistValueEle=Hooks_V1.chromeDriver.findElement(By.cssSelector("input[aria-label=\"Qty.\"]"));
        return wishlistValueEle;
    }

}
