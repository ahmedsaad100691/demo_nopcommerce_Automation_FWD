package org.example.Runners_V1;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/main/resources/Features_V1",
        glue = "org.example.Steps_Definitions_V1",
        tags ="@Smoke_Test_V1",
        plugin = { "pretty",
        "html:target/cucumber.html",
        "json:target/cucumber.json",
        "junit:target/cukes.xml",
        "rerun:target/rerun.txt"}
)

public class runners_V1 extends AbstractTestNGCucumberTests {
}
